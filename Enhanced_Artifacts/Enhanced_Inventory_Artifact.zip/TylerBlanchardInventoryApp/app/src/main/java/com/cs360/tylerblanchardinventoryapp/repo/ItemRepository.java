package com.cs360.tylerblanchardinventoryapp.repo;

import android.content.Context;
import android.content.res.AssetManager;
import android.util.Log;

import androidx.room.Room;

import com.cs360.tylerblanchardinventoryapp.model.Item;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.List;

//Singleton Item Repository to allow classes to interact with the item database
//Classes can utilize full CRUD functionality using this repository
public class ItemRepository {

    private static ItemRepository mItemRepo;
    private final ItemDao mItemDao;
    private final Context mContext;

    public static ItemRepository getInstance(Context context){
        if(mItemRepo == null){
            mItemRepo = new ItemRepository(context);
        }
        return mItemRepo;
    }

    private ItemRepository(Context context){

        this.mContext = context.getApplicationContext();

        ItemDatabase idb = Room.databaseBuilder(context, ItemDatabase.class, "item.db")
                .allowMainThreadQueries()
                .build();
        mItemDao = idb.itemDao();


        if(mItemDao.getAll().isEmpty()){
            //addStarterDataDebug();
            addDataFromFile();
        }

    }

    //Creates starting sample data if the database is initially blank
    private void addStarterDataDebug(){
        Item ex1 = new Item("Matches", 53);
        mItemDao.addItem(ex1);
        Item ex2 = new Item("Toys", 24);
        mItemDao.addItem(ex2);
        Item ex3 = new Item("Plastic Chairs", 5);
        mItemDao.addItem(ex3);
        Item ex4 = new Item("Pencils", 634);
        mItemDao.addItem(ex4);
        Item ex5 = new Item("Pens", 545);
        mItemDao.addItem(ex5);
        Item ex6 = new Item("Erasers", 62);
        mItemDao.addItem(ex6);
        Item ex7 = new Item("Kitchen Utensils", 4);
        mItemDao.addItem(ex7);
        Item ex8 = new Item("Patio Set", 2);
        mItemDao.addItem(ex8);
        Item ex9 = new Item("Trading Cards", 194);
        mItemDao.addItem(ex9);
        Item ex10 = new Item("Notebooks", 73);
        mItemDao.addItem(ex10);

    }

    //Import data from file within assets folder into database
    private void addDataFromFile() {
        Log.d("addDataFromFileFunction", "Starting to add data from file");

        try {
            AssetManager assetManager = mContext.getAssets();
            InputStream inputStream = assetManager.open("csvFiles/largedataset.txt");
            BufferedReader buffer = new BufferedReader(new InputStreamReader(inputStream));
            String rawData;
            String dataTitle;
            int dataQuantity;

            while((rawData = buffer.readLine()) != null){
                //Log.d("addDataFromFileDataGathered", rawData);
                dataTitle = rawData.substring(0, rawData.lastIndexOf(','));
                dataQuantity = Integer.parseInt(rawData.substring(rawData.indexOf(',') + 1));
                //Log.d("addDataFromFileDataGathered", "Title: " + dataTitle + "|Quantity: " + dataQuantity);

                mItemDao.addItem(new Item(dataTitle, dataQuantity));
            }
        }
        catch(IOException e){
            Log.d("addDataFromFileFunctionFAIL", "Failed to access file");
        }

    }

    public List<Item> getAllItems(){
        return mItemDao.getAll();
    }
    public void addItem(Item item){
        mItemDao.addItem(item);
    }
    public void updateItemQuantity(int quantity, long id) {mItemDao.updateItemQuantity(quantity,id);}
    public void deleteItem(Item item) {mItemDao.deleteItem(item);}
    public Item getItemById(long id) {return mItemDao.getItemById(id);}
    public List<Item> getSearchItems(String search) {

        //Remove all special character from user input that could be part of a command (SQL Injection)
        String refactoredSearch = search.replaceAll("[=*;:&$~-]", "");

        return mItemDao.getByInput(refactoredSearch);
    }

}
