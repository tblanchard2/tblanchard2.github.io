package com.cs360.tylerblanchardinventoryapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.cs360.tylerblanchardinventoryapp.model.Item;
import com.cs360.tylerblanchardinventoryapp.repo.ItemRepository;

import java.util.Objects;

public class ItemActivity extends AppCompatActivity {

    private ItemRepository itemRepo;
    private Item dItem;
    private long itemId;
    private TextView itemTitle;
    private TextView itemQuantity;
    private EditText amountChange;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_item);
        itemRepo = ItemRepository.getInstance(getApplication().getApplicationContext());

        if(getIntent().hasExtra("ITEM")){
            dItem = getIntent().getSerializableExtra("ITEM", Item.class);
        }

        itemTitle = findViewById(R.id.itemNameView);
        itemQuantity = findViewById(R.id.itemDescQuantityView);
        amountChange = findViewById(R.id.editQuantityEditText);

        Objects.requireNonNull(getSupportActionBar()).setTitle(getString(R.string.itemMenuTitle, dItem.getTitle()));

        if(dItem != null){
            itemId = dItem.getId();
            itemTitle.setText(dItem.getTitle());
            updateQuantityDisplay();
        }


    }

    //Sets the referenced item to the database's item to retain accurate referencing
    private void refreshItem(){
        dItem = itemRepo.getItemById(itemId);
        updateQuantityDisplay();
    }

    //Updates the quantity display to show the accurate quantity when a change occurs
    private void updateQuantityDisplay(){
        String quantity = getString(R.string.itemQuantity, String.valueOf(dItem.getQuantity()));
        itemQuantity.setText(quantity);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu){
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.item_menu, menu);

        return true;
    }

    public boolean onOptionsItemSelected(@NonNull MenuItem item){

        if(item.getItemId() == R.id.sendNotificationMenu){
            checkNotificationPermission();
            return true;
        }
        else if(item.getItemId() == R.id.itemRemoveMenu){
            confirmRemoveDialog();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    //Decreases the item's quantity by the entered amount when the decrease button is pressed
    //Quantity cannot go below 0 (you can't have a negative amount of a physical item)
    public void onButtonDecrease(View view){
        int oldQuantity = dItem.getQuantity();
        int changeAmount;
        try {   //Ensure that entered quantity is a number, else set quantity changing to zero
            changeAmount = Integer.parseInt(amountChange.getText().toString());
        } catch (NumberFormatException e) {
            changeAmount = 0;
        }

        if(oldQuantity > Integer.MAX_VALUE - changeAmount){
            Toast.makeText(ItemActivity.this, R.string.overflowNotif, Toast.LENGTH_SHORT).show();
        }
        else{
            //Check if quantity is 0 or less before updating the database
            int newQuantity = checkNoStock(oldQuantity - changeAmount, oldQuantity);
            itemRepo.updateItemQuantity(newQuantity, itemId);
            refreshItem();
        }
    }

    //Increases the item's quantity by the entered amount when the increase button is pressed
    //Checks for quantity being zero or less as user is able to enter a negative number if they desire
    public void onButtonIncrease(View view){
        int oldQuantity = dItem.getQuantity();
        int changeAmount;
        try {   //Ensure that entered quantity is a number, else set quantity changing to zero
            changeAmount = Integer.parseInt(amountChange.getText().toString());
        } catch (NumberFormatException e) {
            changeAmount = 0;
        }

        if(oldQuantity > Integer.MAX_VALUE - changeAmount){
            Toast.makeText(ItemActivity.this, R.string.overflowNotif, Toast.LENGTH_SHORT).show();
        }
        else{
            //Check if quantity is 0 or less before updating the database
            int newQuantity = checkNoStock(oldQuantity + changeAmount, oldQuantity);
            itemRepo.updateItemQuantity(newQuantity, itemId);
            refreshItem();
        }
    }

    //Checks if an item's quantity is out of stock (0 or less) and notifies user via SMS if so
    //Second argument checks if the quantity before any change was already zero to prevent multiple out of stock notifications
    //if the stock was already 0
    private int checkNoStock(int quantity, int original){
        if(quantity <= 0){

            //Check if user has granted permission to send notifications to their phone
            if(ContextCompat.checkSelfPermission(ItemActivity.this, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED && original > 0){

                //Create a new notification channel to process and send notifications to the user's phone
                NotificationChannel channel = new NotificationChannel("1", "OutofStock", NotificationManager.IMPORTANCE_DEFAULT);

                NotificationManager notifManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
                notifManager.createNotificationChannel(channel);

                //Create the notification that will be sent to the user's phone to indicate an item is out of stock
                NotificationCompat.Builder notifBuilder = new NotificationCompat.Builder(this, "1")
                        .setSmallIcon(R.drawable.ic_launcher_foreground)
                        .setContentTitle("Item Out of Stock")
                        .setContentText(dItem.getTitle() + " has ran out of stock!")
                        .setPriority(NotificationCompat.PRIORITY_DEFAULT);

                notifManager.notify(1, notifBuilder.build());

            }

            return 0;
        }
        else{
            return quantity;
        }

    }

    //Displays a dialog asking user to confirm their decision to delete an item
    public void confirmRemoveDialog(){
        AlertDialog.Builder alert = new AlertDialog.Builder(this);
            alert.setTitle(R.string.removeItemTitle);
            alert.setMessage(R.string.removeItemMessage);
            alert.setPositiveButton(R.string.removeYes, new DialogInterface.OnClickListener(){
                public void onClick(DialogInterface dialog, int id){
                    //Removes the item from the database and finishes this activity, as this item will no longer exist
                    Toast.makeText(ItemActivity.this, R.string.itemRemoved, Toast.LENGTH_SHORT).show();
                    itemRepo.deleteItem(dItem);
                    finish();
                }
            });
            alert.setNegativeButton(R.string.removeNo, new DialogInterface.OnClickListener(){
                public void onClick(DialogInterface dialog, int id){
                    //Do nothing and close dialog
                }
            });
            alert.create().show();
    }

    //Checks for permission to receive user's phone number and send SMS notifications
    //Asks user to enable permissions if denied, or notifies user that notifications are already enabled
    //Users can enable the activity to request permissions by pressing on the message/SMS icon to the
    //left of the overflow menu on the activity's action bar
    public void checkNotificationPermission(){
        if(ContextCompat.checkSelfPermission(ItemActivity.this, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_DENIED){
            ActivityCompat.requestPermissions(ItemActivity.this, new String[] {Manifest.permission.POST_NOTIFICATIONS} , 1);        }
        else{
            Toast.makeText(ItemActivity.this, R.string.notificationsEnabled, Toast.LENGTH_SHORT).show();
        }
    }

}