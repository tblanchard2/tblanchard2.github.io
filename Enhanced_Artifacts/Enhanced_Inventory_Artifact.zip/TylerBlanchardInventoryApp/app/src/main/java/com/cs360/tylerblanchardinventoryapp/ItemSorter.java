package com.cs360.tylerblanchardinventoryapp;

import android.util.Log;

import com.cs360.tylerblanchardinventoryapp.model.Item;

import java.util.ArrayList;
import java.util.List;

public class ItemSorter {

    //Call the sort method with the given conditionals based on the filter selected
    public List<Item> sortByFilter(List<Item> unsortedData, int filterType){

        List<Item> sortedData;

        /***********************************************************************************
        *  To test the other sorts, simply comment the active method call for each statement
        *  and uncomment the method call for the sort you want to use
        ***********************************************************************************/
        if(filterType == 1){ //Sort alphabetically
            Log.d("Sort Start", "Started sort");

            //sortedData = bubbleSortAlpha(unsortedData);                                      //Bubble sort
            //sortedData = mergeSort(unsortedData, 0, unsortedData.size()-1, filterType);      //Merge sort
            sortedData = heapSort(unsortedData, filterType);                                   //Heap sort

            Log.d("Sort End", "Finished sort");
            return sortedData;
        }
        else if(filterType == 2){ //Sort by lowest quantity
            Log.d("Sort Start", "Started sort");

            //sortedData = bubbleSortQuantityLow(unsortedData);                               //Bubble sort
            //sortedData = mergeSort(unsortedData, 0, unsortedData.size()-1, filterType);     //Merge sort
            sortedData = heapSort(unsortedData, filterType);                                  //Heap sort

            Log.d("Sort End", "Finished sort");
            return sortedData;
        }
        else if(filterType == 3){ //Sort by highest quantity
            Log.d("Sort Start", "Started sort");

            //sortedData = bubbleSortQuantityHigh(unsortedData);                              //Bubble sort
            //sortedData = mergeSort(unsortedData, 0, unsortedData.size()-1, filterType);     //Merge sort
            sortedData = heapSort(unsortedData, filterType);                                  //Heap sort

            Log.d("Sort End", "Finished sort");
            return sortedData;
        }
        else{ //No sort (filterType 0 or any other)
            return unsortedData;
        }
    }

    /******************************************************************************************
     *                             ----Bubble Sort Methods----
     * WARNING: application will complain to be not responding, but it is functioning
     * These methods use the most basic sorting algorithm to sort the data in the app
     * This has an average time complexity of O(n^2), and takes almost 3 minutes
     * to sort 100,000 data entries
     * This highly inefficient and is not recommended to be used in any application
     * that deals with large sets of data, and is only implemented here as a proof of concept
     ******************************************************************************************/
    private List<Item> bubbleSortQuantityLow(List<Item> data){
        boolean sorted = true;

        do{
            sorted = true;
            for(int i = 0; i < data.size()-1; i++){
                if(data.get(i).mQuantity > data.get(i+1).mQuantity){
                    Item temp = data.get(i+1);
                    data.set(i+1, data.get(i));
                    data.set(i, temp);
                    sorted = false;
                }
            }

        }while(!sorted);

        return data;
    }

    private List<Item> bubbleSortQuantityHigh(List<Item> data){
        boolean sorted = true;

        do{
            sorted = true;
            for(int i = 0; i < data.size()-1; i++){
                if(data.get(i).mQuantity < data.get(i+1).mQuantity){
                    Item temp = data.get(i+1);
                    data.set(i+1, data.get(i));
                    data.set(i, temp);
                    sorted = false;
                }
            }

        }while(!sorted);

        return data;
    }

    private List<Item> bubbleSortAlpha(List<Item> data){
        boolean sorted = true;

        do{
            sorted = true;
            for(int i = 0; i < data.size()-1; i++){
                if(data.get(i).mTitle.compareTo(data.get(i+1).mTitle) >= 0){
                    Item temp = data.get(i+1);
                    data.set(i+1, data.get(i));
                    data.set(i, temp);
                    sorted = false;
                }
            }

        }while(!sorted);

        return data;
    }


    /******************************************************************************************
     *                             ----Merge Sort Methods----
     * These methods are part of a more complex sorting algorithm that divides a list by two
     * until it can no longer be divided, and then merges pairs of elements together
     * while sorting until all of the elements are put back into one fully sorted list
     * This has an average time complexity of O(n*log(n)), and took only 160 milliseconds
     * on average to sort 100,000 data entries
     * This is very efficient in sorting large sets of data, as you can barely see any pauses
     * from when the sort is called to when it is finished
     ******************************************************************************************/
    private List<Item> mergeSort(List<Item> data, int left, int right, int comparator){

        if(left < right){
            int middle = (left + right) /2;

            //Recursively split the list into halved sized sublists for more efficient sorting by merging
            mergeSort(data, left, middle, comparator);
            mergeSort(data, middle+1, right, comparator);
            merge(data, left, middle, right, comparator);
        }

        return data;
    }

    //Merges sublists together based on comparator to form a sorted list
    private void merge(List<Item> data, int left, int middle, int right, int comparator){
        int i = 0, j = 0, k = left;
        int leftSize = middle - left + 1;
        int rightSize = right - middle;

        List<Item> leftList = new ArrayList<>();
        List<Item> rightList = new ArrayList<>();

        //Add respective data into each sublist
        for(int x = 0; x < leftSize; x++){
            leftList.add(data.get(left + x));
        }
        for(int y = 0; y < rightSize; y++){
            rightList.add(data.get(middle+1+y));
        }

        //Compare items in both sublists and sort them based on the selected comparator
        while (i < leftSize && j < rightSize){

            //If statement to cover all possible sort methods in one function
            //1: alphabetically 2: low to high quantity 3: high to low quantity
            if((leftList.get(i).mQuantity <= rightList.get(j).mQuantity && comparator == 2)
                    || (leftList.get(i).mQuantity >= rightList.get(j).mQuantity && comparator == 3)
                    || (leftList.get(i).mTitle.compareTo(rightList.get(j).mTitle) < 0 && comparator == 1)){
                data.set(k, leftList.get(i));
                i++;
            }
            else{
                data.set(k, rightList.get(j));
                j++;
            }
            k++;
        }
        //Implement remaining data should one list be larger than the other
        while (i < leftSize){
            data.set(k, leftList.get(i));
            i++;
            k++;
        }
        while (j < rightSize){
            data.set(k, rightList.get(j));
            j++;
            k++;
        }

    }

    /******************************************************************************************
     *                             ----Heap Sort Methods----
     * These methods are part of another complex sorting algorithm that places the data into
     * a complete binary tree, in which one node(data) has no more than two child nodes
     * This tree is "heapified" to place the largest element (or the element that satisfies
     * the comparator the most) at the root of the tree, which is then taken off of the tree
     * and placed into the sorted area of the list, eventually resulting in a sorted list
     * after all nodes in the tree have been rooted and removed
     * This has an average time complexity of O(n*log(n)), and took roughly 160 milliseconds
     * on average to sort 100,000 data entries, similar to the merge sort
     * This is very efficient in sorting large sets of data, as you can barely see any pauses
     * from when the sort is called to when it is finished
     * This is also more efficient storage wise compared to the above merge sort, as less
     * variables and parameters are needed to fully function
     ******************************************************************************************/
    private List<Item> heapSort(List<Item> data, int comparator){

        //Build the heap tree with the given data
        for(int i = data.size()/2 -1; i >=0; i--){
            heapify(data, data.size(), i, comparator);
        }

        //Remove the root element as it is the next sorted element within the list and reheap
        for(int i = data.size()-1; i>=0; i--){
            Item temp = data.get(0);
            data.set(0, data.get(i));
            data.set(i, temp);

            heapify(data, i, 0, comparator);
        }

        return data;
    }

    //Method to convert a list of data into a heap, with the next sorted element being the root
    //allowing for easy identification of the next element to be sorted
    private void heapify(List<Item> data, int dataSize, int root, int comparator){
        int nextSortedElement = root;
        int leftChild = 2 * root + 1;
        int rightChild = 2 * root + 2;

        //Check if the child of the given root/node better matches the comparator than the root/parent
        //1: Alphabetically 2: low to high quantity 3: high to low quantity
        if (leftChild < dataSize && ((data.get(leftChild).mQuantity > data.get(nextSortedElement).mQuantity && comparator == 2)
                                    || (data.get(leftChild).mQuantity < data.get(nextSortedElement).mQuantity && comparator == 3)
                                    || (data.get(leftChild).mTitle.compareTo(data.get(nextSortedElement).mTitle) >= 0 && comparator == 1))){
            nextSortedElement = leftChild;
        }
        if(rightChild < dataSize && ((data.get(rightChild).mQuantity > data.get(nextSortedElement).mQuantity && comparator == 2)
                                    || (data.get(rightChild).mQuantity < data.get(nextSortedElement).mQuantity && comparator == 3)
                                    || (data.get(rightChild).mTitle.compareTo(data.get(nextSortedElement).mTitle) >= 0 && comparator == 1))){
            nextSortedElement = rightChild;
        }
        //Check if the root is no longer the next element to sort (conditions above fulfilled)
        //and sort and reheapify to ensure the correct element is at the root
        if(nextSortedElement != root){
            Item temp = data.get(root);
            data.set(root, data.get(nextSortedElement));
            data.set(nextSortedElement, temp);

            heapify(data, dataSize, nextSortedElement, comparator);
        }
    }


}
