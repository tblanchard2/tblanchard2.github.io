package com.cs360.tylerblanchardinventoryapp.repo;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

import com.cs360.tylerblanchardinventoryapp.model.Login;

import java.util.List;

@Dao
public interface LoginDao {

    @Query("SELECT * FROM login")
    List<Login> getAllLogins();
    @Query("SELECT * FROM login WHERE username LIKE :name AND password LIKE :pass")
    List<Login> getValidCredentials(String name, String pass);

    @Query("SELECT * FROM login WHERE username LIKE :name")
    List<Login> getUsernames(String name);

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    long addUser(Login user);

}
