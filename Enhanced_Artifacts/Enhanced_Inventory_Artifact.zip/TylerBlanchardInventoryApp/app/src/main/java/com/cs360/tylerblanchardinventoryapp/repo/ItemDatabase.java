package com.cs360.tylerblanchardinventoryapp.repo;

import androidx.room.Database;
import androidx.room.RoomDatabase;

import com.cs360.tylerblanchardinventoryapp.model.Item;

@Database(entities = {Item.class}, version = 1)
public abstract class ItemDatabase extends RoomDatabase {
    public abstract ItemDao itemDao();
}
