package com.cs360.tylerblanchardinventoryapp;

import android.annotation.SuppressLint;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.cs360.tylerblanchardinventoryapp.model.Item;

import java.util.List;

//Adapter and holder classes to properly display all items within the recycler grid
public class GridAdapter extends RecyclerView.Adapter<GridAdapter.ItemHolder> {

    private List<Item> mItems;
    private OnCardClickListener onCardClickListener;


    public GridAdapter(List<Item> items) {
        mItems = items;
    }

    @NonNull
    @Override
    public ItemHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        return new ItemHolder(inflater, parent);
    }

    //Bind view with data labels to allow for item name and quantity to be displayed on each card
    //Suppressed error on int position as position is only used immediately in this method and is never called later on
    @Override
    public void onBindViewHolder(@NonNull ItemHolder holder, @SuppressLint("RecyclerView") int position) {
        holder.bind(mItems.get(position), position);

        //Allows cards/items to be clickable
        holder.itemView.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                if(onCardClickListener != null){
                    onCardClickListener.onCardClick(position, mItems.get(position));
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        return mItems.size();
    }

    public void setOnClickListener(OnCardClickListener onCardClickListener) {
        this.onCardClickListener = onCardClickListener;
    }


    //Interface to allow implementation of clicking on recycler view
    public interface OnCardClickListener {
        void onCardClick(int position, Item item);
    }


    static class ItemHolder extends RecyclerView.ViewHolder{
        private final TextView mNameTextView;
        private final TextView mQuantityTextView;

        public ItemHolder(LayoutInflater inflater, ViewGroup parent) {
            super(inflater.inflate(R.layout.recycler_view_items, parent, false));
            mNameTextView = itemView.findViewById(R.id.itemTitleView);
            mQuantityTextView = itemView.findViewById(R.id.itemQuantityView);
        }

        public void bind(Item item, int position) {
            mNameTextView.setText(item.getTitle());
            String quantityLabel = "Quantity: " + String.valueOf(item.getQuantity());
            mQuantityTextView.setText(quantityLabel);
        }




    }

}
