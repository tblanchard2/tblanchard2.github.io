package com.cs360.tylerblanchardinventoryapp.repo;

import android.content.Context;

import androidx.room.Room;

import com.cs360.tylerblanchardinventoryapp.model.Login;

import java.util.List;

//Singleton Login Repository to allow classes to interact with the login database
//Classes can only add or read login credentials from the database
public class LoginRepository {

    private static LoginRepository mloginRepo;
    private final LoginDao mloginDao;

    public static LoginRepository getInstance(Context context){
        if (mloginRepo == null){
            mloginRepo = new LoginRepository(context);
        }
        return mloginRepo;
    }

    private LoginRepository(Context context){
        LoginDatabase ldb = Room.databaseBuilder(context, LoginDatabase.class, "login.db")
                .allowMainThreadQueries()
                .build();
        mloginDao = ldb.loginDao();

        if(mloginDao.getAllLogins().isEmpty()){
            addStarterLoginCredentials();

        }
    }

    //Used as default login if no credentials already exist in the database
    private void addStarterLoginCredentials(){
        Login defUsr = new Login("username", "password");
        mloginDao.addUser(defUsr);

    }

    public List<Login> getVerificatedCredentials(String user, String pass){
        return mloginDao.getValidCredentials(user, pass);
    }

    public List<Login> getMatchingUsernames(String user){
        return mloginDao.getUsernames(user);
    }

    public void addUser(Login user){
        mloginDao.addUser(user);
    }

}
