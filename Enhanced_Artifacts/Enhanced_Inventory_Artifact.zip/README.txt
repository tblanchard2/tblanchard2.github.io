-------------------------------------------
Installation Requirements
-------------------------------------------
Make sure you have Android Studio installed to build and run this project in the android emulator

Studio version used to build this project: Hedgehog | 2023.1.1 Patch 1

Download link: https://developer.android.com/studio/archive
-------------------------------------------
Setup
-------------------------------------------
To run this app, simply import the project into Android Studio, set the current run configuration to either default (LoginActivity) or GridActivity, then click run

A new window should open with an android emulator that will show the application

If there are no custom run configurations, you can create a new configuration to launch the specified activity at com.cs360.tylerblanchardinventoryapp.GridActivity, which will skip the login activity and launch strait to the main activity that was enhanced

If launching from the login activity, you can enter "username, password" as the username and password respectivly and press login, or you can enter your own credentials and press sign up, which will allow those credentials to be used to login

