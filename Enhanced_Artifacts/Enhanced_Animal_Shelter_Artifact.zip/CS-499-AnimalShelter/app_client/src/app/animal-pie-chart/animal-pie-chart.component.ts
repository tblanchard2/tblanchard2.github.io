import { Component, Input, OnChanges, SimpleChanges } from '@angular/core';
import { Chart } from 'chart.js/auto';
import { BreedAmount } from '../models/breed';

@Component({
  selector: 'app-animal-pie-chart',
  standalone: true,
  imports: [],
  templateUrl: './animal-pie-chart.component.html',
  styleUrl: './animal-pie-chart.component.css'
})

/************************************************************************************* 
 * Angular class that generates a pie chart which displays the count of every
 * breed type within the datatable
 * This uses the Chart.js Library, which is a tool to create multiple different
 * types of dynamic and high quality charts
 * 
 * 
 * Link to library: https://www.chartjs.org/docs/latest/
*************************************************************************************/ 
export class AnimalPieChartComponent implements OnChanges{
  @Input() breed: any;

  private breedList = new Array<BreedAmount>;
  public chart: any;
  private breedDisplayNames = new Array<String>;
  private breedDisplayCounts = new Array<any>;

  // Hardcoded varoable to determine the max amout of breeds to display on the chart
  // An unlimited amount of breeds would make the chart unreadable
  private breedDisplayAmount = 10;

  // Itterates through given animal list to gather a count of each breed
  private countBreeds(): void{
    for(var i = 0; i < this.breed.length; i++){
      var breedName = this.breed[i].breed;
      var breedFound = false;
      // Checks to see if current breed is already in breed list
      for(var j = 0; j < this.breedList.length; j++){
        if(this.breedList[j].breed_name == breedName){
          this.breedList[j].breed_count += 1;
          breedFound = true;
        }
      }
      // Adds breed to breed list if it's not already in there
      if(!breedFound){
        let newBreed: BreedAmount = {
          breed_name: breedName,
          breed_count: 1
        }
        this.breedList.push(newBreed);
      }
    }
  }

  // Sorts through breed list and splits the names and counts to be places in the correct spot for the chart
  // Items are split after sorting so the same index on both split lists relate to the same object
  private sortBreeds(): void{

    // Sort list of breeds based on highest to lowest count
    this.breedList.sort((a, b) => (a.breed_count > b.breed_count ? -1 : 1));

    for(var i = 0; i < this.breedDisplayAmount && i < this.breedList.length; i++){
        this.breedDisplayNames.push(this.breedList[i].breed_name);
        this.breedDisplayCounts.push(this.breedList[i].breed_count);
    }

    // Combines any additional breeds into an 'Other' category to prevent the chart from displaying too many breeds at once
    var otherCount = 0;
    for(var j = this.breedDisplayAmount; j < this.breedList.length; j++){
        otherCount += this.breedList[j].breed_count;
    }
    if(otherCount > 0){
      this.breedDisplayNames.push("Other");
      this.breedDisplayCounts.push(otherCount);
    }

  }

  // Listens for an animal list to be recieved and 
  // generates a chart depicting all breeds from the animals recieved by the database
  ngOnChanges(changes: SimpleChanges): void {
    if(changes['breed']){
      
      this.breedList = new Array<BreedAmount>;
      this.breedDisplayNames = new Array<String>;
      this.breedDisplayCounts = new Array<any>;

      this.countBreeds();

      this.sortBreeds();

      if(Chart.getChart("animalChart")) {
        Chart.getChart("animalChart")?.destroy();
      }

      this.chart = new Chart("animalChart", {
        type: 'pie',
        data: {
          labels: this.breedDisplayNames,
          datasets: [{
            label: 'Animals',
            data: this.breedDisplayCounts,
            backgroundColor: [
              '#E28A88',
              '#F48FB1',
              '#CE93D8',
              '#B39DDB',
              '#9FA8DA',
              '#90CAF9',
              '#81D4FA',
              '#80DEEA',
              '#80CBC4',
              '#A5D6A7',
              '#C5E1A5'
            ],
            hoverOffset: 4
          }],
        },
        options: {
          aspectRatio: 1
        }
  
      });


    }
  }

}
