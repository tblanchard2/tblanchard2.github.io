import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AnimalPieChartComponent } from './animal-pie-chart.component';

describe('AnimalPieChartComponent', () => {
  let component: AnimalPieChartComponent;
  let fixture: ComponentFixture<AnimalPieChartComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AnimalPieChartComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AnimalPieChartComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
