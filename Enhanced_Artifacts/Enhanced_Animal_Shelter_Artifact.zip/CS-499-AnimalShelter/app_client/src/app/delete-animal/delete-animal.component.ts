import { Component, OnInit } from '@angular/core';
import { AnimalDataService } from '../services/animal-data.service';
import { Animal } from '../models/animal';
import { Router } from '@angular/router';

@Component({
  selector: 'app-delete-animal',
  standalone: true,
  imports: [],
  templateUrl: './delete-animal.component.html',
  styleUrl: './delete-animal.component.css'
})

/************************************************************************************* 
 * Angular class to delete an animal within the database & displayed on the table
 * 
 * Returns to the front end (app.component) if an animal is successfully deleted
 * of if no valid animal/animal id is stored or found in the database
 * 
 * Requires an animal to be selected on the table first and page must be reloaded
 * after deletion for the table to correctly display the remaining data
*************************************************************************************/ 
export class DeleteAnimalComponent implements OnInit{

  animalToRemove!: Animal

  constructor(
    private animalService: AnimalDataService,
    private router: Router
  ){}


  // Find the animal with the currently selected ID so it can be deleted from the database
  ngOnInit(): void {

    let animalId = localStorage.getItem("selectedAnimalId");
    if (!animalId) {
      alert("Could not find an animal id in storage. No animal may have been selected on the table, or the animal may not exist within the database anymore");
      return;
    }

    this.animalService.getOneAnimal(animalId).subscribe({
      next: (value: any) => {
        this.animalToRemove = value;

        if(!value){
          console.log("No Animal Recieved!");
        }
        else{
          console.log("Animal: " + animalId + " Recieved");
        }

        // Popup browser confirmation that displays the found object to be deleted to make sure the user wants
        // to delete the given object
        if(confirm("Are you sure you want to remove " + this.animalToRemove.name + " with the ID of " + animalId + "?")){
          this.delete(animalId);
          this.router.navigate(['']);
          alert("The animal has been removed from the database. Please refresh page for changes to occur");
        }
        else{
          console.log("Deletion has been aborted");
          this.router.navigate(['']);
        }

      },
      error: (error: any) => {
        console.log('Error: ' + error);
        this.router.navigate(['']);
      }
    })
    
    

  }

  // Calls the service's delete query with the chosen ID to remove the object from the database
  delete(animal_id: String): void{
    this.animalService.removeAnimal(animal_id).subscribe({
      next: (data: any) => {
        console.log("Removed: " + data);
      },
      error: (error: any) => {
        console.log('Error: ' + error);
      }
    });
  }

}
