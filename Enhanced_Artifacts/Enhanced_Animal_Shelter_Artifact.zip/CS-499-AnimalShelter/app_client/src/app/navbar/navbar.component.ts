import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { AuthenticationService } from '../services/authentication.service';

@Component({
  selector: 'app-navbar',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './navbar.component.html',
  styleUrl: './navbar.component.css'
})

/************************************************************************************* 
 * Angular class for a simple navigation bar that contains the different CRUD and login
 * buttons to manipulate the database and access the manipulation functions
 * 
 * Contains HTML checks and basic authentication features to hide CRUD buttons from
 * users not logged in (i.e. not employees/admins of this site)
*************************************************************************************/ 
export class NavbarComponent implements OnInit{

    constructor(
      private router: Router,
      private authService: AuthenticationService
    ) {}

    ngOnInit() {}

    public addAnimal(): void {
      this.router.navigate(['add-animal']);
    }

    public editAnimal(): void {
      this.router.navigate(['edit-animal']);
    }

    public deleteAnimal(): void {
      this.router.navigate(['delete-animal']);
    }

    public isLoggedIn(): boolean {
      return this.authService.isLoggedIn();
    }

    public onLogout(): void{
      return this.authService.logout();
    }

    public onLogin(): void{
      this.router.navigate(['login']);
    }
}
