import { AfterViewInit, Component, Injectable, input, Input, OnChanges, OnInit, SimpleChanges } from '@angular/core';
import { LeafletModule } from '@bluehalo/ngx-leaflet'
import * as Leaflet from 'leaflet'

@Component({
  selector: 'app-animal-map',
  standalone: true,
  imports: [LeafletModule],
  templateUrl: './animal-map.component.html',
  styleUrl: './animal-map.component.css'
})

/************************************************************************************* 
 * Angular class that generates a map centered around Austin Texas, which displays
 * the location of an animal when selected within the datatable
 * This uses the Leaflet Library, which is an open source tool to create a dynamic
 * map image that can display markers indicating the location of an animal
 * 
 * 
 * Link to library: https://leafletjs.com/
*************************************************************************************/ 
export class AnimalMapComponent implements AfterViewInit, OnChanges{
  @Input() markerLocation: any;
    
  map: any;
  markerGroup : any;

  // Set up map view centered around Austin Texas
  ngAfterViewInit(): void {

    this.map = Leaflet.map('map').setView([30.3, -97.7], 9);
    this.markerGroup = Leaflet.layerGroup().addTo(this.map);

    Leaflet.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
      maxZoom: 19,
      attribution: '&copy; <a href="http://www.openstreetmap.org/copyright">OpenStreetMap</a>'
    }).addTo(this.map);

  }

  // Place a marker at the given coordinates to display where a specific animal is located
  ngOnChanges(changes: SimpleChanges): void {
    if(changes['markerLocation']){
      //DEGUB
      //console.log("Recieving data from parent: " + changes['markerLocation'].currentValue.animal_id);

      var lat = changes['markerLocation'].currentValue.latitude;
      var long = changes['markerLocation'].currentValue.longitude;

      this.markerGroup.clearLayers();
      Leaflet.marker([lat, long]).bindPopup(lat + ', ' + long).addTo(this.markerGroup);
      
    }
    
  }
  
}

