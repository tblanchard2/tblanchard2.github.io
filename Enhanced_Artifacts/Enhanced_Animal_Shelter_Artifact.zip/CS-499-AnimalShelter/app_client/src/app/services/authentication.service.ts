import { Injectable } from '@angular/core';
import { User } from '../models/user';
import { AuthResponce } from '../models/auth-responce';
import { AnimalDataService } from './animal-data.service';

@Injectable({
  providedIn: 'root'
})

// Authentication service to authenticate front end users to the back end API calls that need authentication
export class AuthenticationService {

  constructor(
    private animalService: AnimalDataService
  ) { }

  authRes: AuthResponce = new AuthResponce();

  // Get the current JWT token from storage for verification purposes in other areas of the application
  public getToken(): string {
    let out: any;
    out = localStorage.getItem('animal-token');

    if(!out){
      return '';
    }
    return out;
  }

  // Save the current JWT token into local storage for use later
  public saveToken(token: string): void{
    localStorage.setItem('animal-token', token);
  }

  // Remove the JWT token on logout so it cannot be used for authentication anymore
  public logout(): void{
    localStorage.removeItem('animal-token');
  }

  // Check if a user is logged in to correctly verify users and display the proper nav buttons
  public isLoggedIn(): boolean {
    const token: string = this.getToken();

    if(token){
      const payload = JSON.parse(atob(token.split('.')[1]));
      return payload.exp > (Date.now() / 1000);
    }
    else{
      return false;
    }
  }

  // Get the current logged in user of this instance
  public getCurrentUser(): User {
    const token: string = this.getToken();
    const {email, name} = JSON.parse(atob(token.split('.')[1]));
    return {email, name} as User;
  }

  // Initiate login to authenticate user as an admin that can utilize front end database CRUD management API calls
  public login(user: User, pass: string): void {
    this.animalService.login(user,pass)
      .subscribe({
        next: (value: any) => {
          if(value){
            this.authRes = value;
            this.saveToken(this.authRes.token);
          }
        },
        error: (error: any) => {
          console.log('Error: ' + error);
        }
      })
  }
}
