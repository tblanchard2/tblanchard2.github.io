import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Animal } from '../models/animal'
import { User } from '../models/user';
import { AuthResponce } from '../models/auth-responce';

@Injectable({
  providedIn: 'root'
})

// Data service to interact with API calls to recieve animal data
export class AnimalDataService {

  constructor(private http: HttpClient) { }

  url = 'http://localhost:3000/api/animals';
  baseUrl = 'http://localhost:3000/api';

  login(user: User, pass: string): Observable<AuthResponce> {
    return this.handleAuthAPICall('login', user, pass);
  }

  // Method required to send login request to API, authenticating user as an admin of this site
  handleAuthAPICall(endpoint: string, user: User, pass: string): Observable<AuthResponce> {
    let formData = {
      name: user.name,
      email: user.email,
      password: pass
    };
    return this.http.post<AuthResponce>(this.baseUrl + '/' + endpoint, formData);
  }

  getAnimals() : Observable<Animal[]> {
      return this.http.get<Animal[]>(this.url);
  }

  getAnimalWaterFilter() : Observable<Animal[]> {
    return this.http.get<Animal[]>(this.url + '-water');
  }

  getAnimalWildFilter() : Observable<Animal[]> {
    return this.http.get<Animal[]>(this.url + '-wild');
  }

  getAnimalTrackingFilter() : Observable<Animal[]> {
    return this.http.get<Animal[]>(this.url + '-tracking');
  }

  getAnimalAdoptableFilter() : Observable<Animal[]> {
    return this.http.get<Animal[]>(this.url + '-adoptable');
  }

  getOneAnimal(animal_id: String) : Observable<Animal[]> {
      return this.http.get<Animal[]>(this.url + '/' + animal_id);
  }

  addAnimal(newAnimal: Animal) : Observable<Animal> {
    return this.http.post<Animal>(this.url, newAnimal);
  }

  updateAnimal(animal_id: String, updatedAnimal: Animal) : Observable<Animal> {
    return this.http.put<Animal>(this.url + '/' + animal_id, updatedAnimal);
  }

  removeAnimal(animal_id: String) : Observable<Animal> {
    return this.http.delete<Animal>(this.url + '/' + animal_id);
  }

}
