import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthenticationService } from '../services/authentication.service';
import { User } from '../models/user';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})

/************************************************************************************* 
 * Angular class for a simple login form menu that allows admins to enter credentials
 * to log into the website and access the front end database controle (add, edit, delete)
 * 
 * Compares the inputted credentials with the stored credentials in the user database
 * to authenticate user as a proper administrator of the site
 * 
 * Requires credentials to be inputted into the database via the server register method
 * before login attempts can be made, which can be done either through manual API POST 
 * calls to localhost:3000/api/register or through the user-seed.js node file 
*************************************************************************************/ 
export class LoginComponent {
  public formError: string = '';
  submitted = false;

  credentials = {
    name: '',
    email: '',
    password: ''
  }

  constructor(
    private router: Router,
    private authService: AuthenticationService
  ) {}

  // Check if all fields are filled before attempting login
  public onLoginSubmit(): void {
    this.formError = '';
    if(!this.credentials.email || !this.credentials.password || !this.credentials.name){
      this.formError = 'All fields are required';
      this.router.navigateByUrl('#');
    }
    else{
      this.login();
    }
  }

  // Perform login process to validate and authenticate user
  private login(): void { 
    let newUser = {
      name: this.credentials.name,
      email: this.credentials.email
    } as User;

    this.authService.login(newUser, this.credentials.password);

    if(this.authService.isLoggedIn()){
      this.router.navigate(['']);
    }
    else{
      // Wait for 3 seconds and try again in the possible case that the auth service is busy processing something else
      var timer = setTimeout(() => {
        if(this.authService.isLoggedIn()){
          this.router.navigate(['']);
        }
      }, 3000);
    }
  }

  // Close login component and reroute back to front end if user cancels 
  public onCancel() {
    this.router.navigate(['']);
  }

}
