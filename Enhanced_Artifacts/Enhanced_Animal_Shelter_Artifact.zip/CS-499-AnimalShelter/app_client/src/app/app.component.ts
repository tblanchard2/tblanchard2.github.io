import { Component, OnInit, ViewChild } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { AnimalTableComponent } from "./animal-table/animal-table.component";
import { AnimalMapComponent } from './animal-map/animal-map.component';
import { AnimalPieChartComponent } from './animal-pie-chart/animal-pie-chart.component';
import { NavbarComponent } from "./navbar/navbar.component";
import { Animal } from './models/animal';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, AnimalTableComponent, AnimalMapComponent, AnimalPieChartComponent, NavbarComponent, CommonModule],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent implements OnInit{
  @ViewChild(AnimalTableComponent) tableChile!: AnimalTableComponent;

  title = 'Grazioso Salvare Animal Dashboard';

  selectedAnimal!: Animal;
  markerLocation: any;
  breed!: any;
  filter!: any;
  active_filter = localStorage.getItem("ActiveFilter");

  // Updates the marker value with a selected animal entry, which the map component waits for
  // to update the marker's position on the map accordingly
  updateMap(value:any){

    this.selectedAnimal = value;
    this.markerLocation = value;

  }

  // Updates the pie chart with the list of animals gathered from the last database call
  // so pie component can utilize animal data
  updatePie(value:any){
      this.breed = value;
  }

  // 'Updates' the datatable with the list of animals that fits the selected filter option
  // As the Angular Datatables are static and cannot be changed after implementation
  // we store the chosen filter into local storage and reload the entire page, forcing
  // the table component to reinitialize with the correct list of animals
  onFilterClicked(){
    var filter = $("#table_filter").val();

    this.filter = filter;

    localStorage.setItem("ActiveFilter", this.filter);

    window.location.reload();
    
    
  }

  ngOnInit(): void {
    console.log("The current filter in storage is: " + localStorage.getItem("ActiveFilter"));
  }

}
