// Animal interface to define animal data structure to front-end
export interface Animal {
    _id: String,
    animal_id: String,
    name: String,
    animal_type: String,
    breed: String,
    sex: String,
    age: String,
    color: String,
    admittance: String,
    animal_status: String,
    latitude: Number,
    longitude: Number
}