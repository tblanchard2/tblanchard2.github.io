// Breed data structure to allow for breeds to be associated with their count within the datatabase
export interface BreedAmount{
    breed_name: String,
    breed_count: number
}