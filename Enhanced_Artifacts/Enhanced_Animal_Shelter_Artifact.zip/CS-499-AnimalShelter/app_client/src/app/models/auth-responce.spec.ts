import { AuthResponce } from './auth-responce';

describe('AuthResponce', () => {
  it('should create an instance', () => {
    expect(new AuthResponce()).toBeTruthy();
  });
});
