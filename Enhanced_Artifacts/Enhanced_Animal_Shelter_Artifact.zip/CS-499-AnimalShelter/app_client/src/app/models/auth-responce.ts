export class AuthResponce {
    token: string;

    constructor(){
        this.token = '';
    }
}
