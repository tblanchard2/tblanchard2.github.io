import { HttpInterceptorFn } from '@angular/common/http';
import { Injectable, Provider } from '@angular/core';
import { HttpRequest, HttpHandler, HttpEvent } from '@angular/common/http';
import { HttpInterceptor, HTTP_INTERCEPTORS } from '@angular/common/http';
import { Observable } from 'rxjs';
import { AuthenticationService } from '../services/authentication.service';

export const jwtInterceptor: HttpInterceptorFn = (req, next) => {
  return next(req);
};

/************************************************************************************* 
 * Angular Interceptor/Injectable component that interceps any request to the
 * server and inserts the stored JWT token (if applicable) in said request
 * 
 * This is required so the valid JWT token attached to a successful logged in user
 * can be sent back to the server, validating the responce as a authenticated responce
 * and fulfilling the request
*************************************************************************************/ 
@Injectable()
export class JwtInterceptor implements HttpInterceptor{

  constructor(
    private authService: AuthenticationService
  ) {}

  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    
    var isAuthAPI: boolean;

    if(req.url.startsWith('login')){
      isAuthAPI = true;
    }
    else{
      isAuthAPI = false;
    }

    // Insert token into request if user is logged in and not in the login page
    if(this.authService.isLoggedIn() && !isAuthAPI){
      let token = this.authService.getToken();

      const authReq = req.clone({
        setHeaders: {
          Authorization: `Bearer ${token}`
        }
      });
      return next.handle(authReq);
    }
    return next.handle(req);    
  }
}

export const authInterceptProvider: Provider = {
  provide: HTTP_INTERCEPTORS,
  useClass: JwtInterceptor, multi: true
};
