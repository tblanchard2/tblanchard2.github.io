import { Routes } from '@angular/router';
import { AddAnimalComponent } from './add-animal/add-animal.component';
import { EditAnimalComponent } from './edit-animal/edit-animal.component';
import { DeleteAnimalComponent } from './delete-animal/delete-animal.component';
import { LoginComponent } from './login/login.component';

export const routes: Routes = [
    { path: 'add-animal', component: AddAnimalComponent},
    { path: 'edit-animal', component: EditAnimalComponent},
    { path: 'delete-animal', component: DeleteAnimalComponent},
    { path: 'login', component: LoginComponent}
];
