import { Component, OnInit, EventEmitter, Output, ViewChild, OnDestroy, AfterViewInit, Input, OnChanges, SimpleChanges, InjectionToken } from '@angular/core';
import { Animal } from '../models/animal';
import { AnimalDataService } from '../services/animal-data.service';
import { CommonModule } from '@angular/common';

import { Config } from 'datatables.net'
import { DataTableDirective, DataTablesModule } from 'angular-datatables';
import { Subject } from 'rxjs';


@Component({
  selector: 'app-animal-table',
  standalone: true,
  imports: [CommonModule, DataTablesModule],
  templateUrl: './animal-table.component.html',
  styleUrl: './animal-table.component.css',
  providers: [AnimalDataService]
})

/************************************************************************************* 
 * Angular class that generates a table of all animals to be displayed onto the dashboard
 * This uses the Angular DataTables library, which is a offset of the DataTables jQuery
 * plug-in that generates a dynamic table with searching, sorting, and paging functons
 * 
 * 
 * Link to library: https://l-lin.github.io/angular-datatables/#/welcome
*************************************************************************************/ 
export class AnimalTableComponent implements OnInit {

  @Output() tableToMapEmitter = new EventEmitter();
  @Output() tableToPieEmitter = new EventEmitter();

  animalList!: Animal[];
  dataTable: Config = {};
  dtTrigger: Subject<any> = new Subject();
  selectFilter: any;

  // Connect to service middleware to interact with database
  constructor(private animalDataService: AnimalDataService) {
    //DEBUG
    //console.log('animal table constructed');
  }

  // Get data from angular service that interacts with the API
  private getData(): void {
    this.animalDataService.getAnimals().subscribe({
      next: (value: any) => {
        this.animalList = value;
        this.tableToPieEmitter.emit(value); //Send animal data to pie chart component

        if(value.length > 0){
          console.log(value.length + " animals found");
        }
        else{
          console.log("No animals were found!");
        }
      },
      error: (error: any) => {
        console.log("An unexpected error has occured when getting data into component");
      }
    })
  }

  // Click handler to send animal data to parent component,
  // which sends it to child map component
  private clickHandler(data: any): void{
      var related_id = data[0];

      this.animalDataService.getOneAnimal(related_id).subscribe({
        next: (value: any) => {
          localStorage.setItem("selectedAnimalId", value.animal_id);
          this.tableToMapEmitter.emit(value);
        },
        error: (error: any) => {
          console.log("An unexpected error has occured when getting data into component: " + error);
        }

      })

  }

  // Check what filter is active currently and call the respective service query to get the animal data needed
  // If no filter is selected, use the getData() method to get all animals in the database
  updateData(): void {
    var filter = $("#table_filter").val();
    console.log(filter);

    if(this.selectFilter == 'adoptable'){
      this.animalDataService.getAnimalAdoptableFilter().subscribe({
        next: (value: any) => {
          this.animalList = value;
          this.tableToPieEmitter.emit(value); //Send animal data to pie chart component
  
          if(value.length > 0){
            console.log(value.length + " animals found");
          }
          else{
            console.log("No animals were found!");
          }
        },
        error: (error: any) => {
          console.log("An unexpected error has occured when getting data into component");
        }
      })
    }
    else if(this.selectFilter == 'water_rescue'){
      this.animalDataService.getAnimalWaterFilter().subscribe({
        next: (value: any) => {
          this.animalList = value;
          this.tableToPieEmitter.emit(value); //Send animal data to pie chart component
  
          if(value.length > 0){
            console.log(value.length + " animals found");
          }
          else{
            console.log("No animals were found!");
          }
        },
        error: (error: any) => {
          console.log("An unexpected error has occured when getting data into component");
        }
      })
    }
    else if(this.selectFilter == 'wilderness_rescue'){
      this.animalDataService.getAnimalWildFilter().subscribe({
        next: (value: any) => {
          this.animalList = value;
          this.tableToPieEmitter.emit(value); //Send animal data to pie chart component
  
          if(value.length > 0){
            console.log(value.length + " animals found");
          }
          else{
            console.log("No animals were found!");
          }
        },
        error: (error: any) => {
          console.log("An unexpected error has occured when getting data into component");
        }
      })
    }
    else if(this.selectFilter == 'disaster_tracking'){
      this.animalDataService.getAnimalTrackingFilter().subscribe({
        next: (value: any) => {
          this.animalList = value;
          this.tableToPieEmitter.emit(value); //Send animal data to pie chart component
  
          if(value.length > 0){
            console.log(value.length + " animals found");
          }
          else{
            console.log("No animals were found!");
          }
        },
        error: (error: any) => {
          console.log("An unexpected error has occured when getting data into component");
        }
      })
    }
    else{
      this.getData();
    }
    


  }

  // Initialize the datatable
  ngOnInit(): void {

    this.selectFilter = localStorage.getItem("ActiveFilter");
    console.log(this.selectFilter);

    this.updateData();


    this.dataTable = {
      pagingType: 'full_numbers',
      pageLength: 10,
      processing:true,
      destroy: true,

      // Callback function that occurs whenever a row on the datatable is clicked
      rowCallback: (row: Node, data: any[] | Object, index: number) => {
        $('td', row).off('click'); //required 
        $('td', row).on('click', () => {
          this.clickHandler(data);
        });
      }
    };

    

  }
}

export const ANIMAL_SERVICE = new InjectionToken<AnimalDataService>('animalDataService');
