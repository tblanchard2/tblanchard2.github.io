import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { AnimalDataService } from '../services/animal-data.service';
import { Animal } from '../models/animal';

@Component({
  selector: 'app-edit-animal',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './edit-animal.component.html',
  styleUrl: './edit-animal.component.css'
})

/************************************************************************************* 
 * Angular class to update any animals within the database & displayed on the table
 * 
 * Utilizes form builders and automatically fills the form with the current data
 * to allow admins to update the appropiate data and submit it to the database
 * 
 * Returns to the front end (app.component) upon submission/cancelation or
 * of if no valid animal/animal id is stored or found in the database
 * 
 * Form appears at the bottom of the page and requires an item to be selected on the table
 * and the page to be reloaded to update the datatable display
*************************************************************************************/ 
export class EditAnimalComponent implements OnInit {
  public editAnimal!: FormGroup;
  animalToEdit!: Animal;
  originalAnimalID!: String;
  submitted = false;

  constructor(
    private formBuilder: FormBuilder,
    private router: Router,
    private animalService: AnimalDataService
  ) { }


  // Generate the structure of the form and fill it with the selected object's data to allow for edits to be made
  ngOnInit(): void {

    console.log("Selected animal id is: " + localStorage.getItem("selectedAnimalId"));
    let animalId = localStorage.getItem("selectedAnimalId");
    if (!animalId) {
      alert("Could not find an animal id in storage. No animal may have been selected on the table, or the animal may not exist within the database anymore");
      this.router.navigate(['']);
      return;
    }
    this.originalAnimalID = animalId;

    this.editAnimal = this.formBuilder.group({
      _id: [],
      animal_id: ['', Validators.required],
      name: ['', Validators.required],
      animal_type: ['', Validators.required],
      breed: ['', Validators.required],
      sex: ['', Validators.required],
      age: ['', Validators.required],
      color: ['', Validators.required],
      admittance: ['', Validators.required],
      animal_status: ['', Validators.required],
      latitude: ['', Validators.required],
      longitude: ['', Validators.required],
    })

    this.animalService.getOneAnimal(animalId).subscribe({
      next: (value: any) => {
        this.animalToEdit = value;

        this.editAnimal.patchValue(this.animalToEdit);
        if(!value){
          console.log("No Animal Recieved!");
        }
        else{
          console.log("Animal: " + animalId + " Recieved");
        }
      },
      error: (error: any) => {
        console.log('Error: ' + error);
        this.router.navigate(['']);
      }
    })
  }

  // Check if user has submitted the entry and validate submission so it can be updated in the database
  public onSubmit() {
    this.submitted = true;
    if (this.editAnimal.valid) {
      this.animalService.updateAnimal(this.originalAnimalID, this.editAnimal.value)
        .subscribe({
          next: (data: any) => {
            console.log("Updated data: ", data);
            this.router.navigate(['']);
            alert("Animal Updated Please refresh the page for the table to update with the new changes.");
          },
          error: (error: any) => {
            console.log('Error: ' + error);
            this.router.navigate(['']);
          }
        })
    }
  }

  // Close edit animal component and reroute back to front end if user cancels 
  public onCancel() {
    this.router.navigate(['']);
  }

  // Get the form short name to access form fields
  get f() { return this.editAnimal.controls; }
}
