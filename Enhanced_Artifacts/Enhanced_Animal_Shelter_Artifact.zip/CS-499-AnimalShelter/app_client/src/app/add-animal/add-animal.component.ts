import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule} from '@angular/forms';
import { Router } from '@angular/router';
import { AnimalDataService } from '../services/animal-data.service';

@Component({
  selector: 'app-add-animal',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './add-animal.component.html',
  styleUrl: './add-animal.component.css'
})

/************************************************************************************* 
 * Angular class for the creation of new animal entries to be inserted into the database
 * 
 * Utilizes form builders to allow admins to enter the appropiate data and sumbit that
 * to the database and returns to the front end (app.component) upon submission/cancelation
 * 
 * Form appears at the bottom of the page and requires page to be reloaded to update
 * the datatable display
*************************************************************************************/ 
export class AddAnimalComponent  implements OnInit{

    public addAnimal!: FormGroup;
    submitted = false;

    constructor  (
      private formBuilder: FormBuilder,
      private router: Router,
      private animalService: AnimalDataService
    ) {}


    // Generate the structure of the form to allow new animal objects to be correctly created
    ngOnInit(): void {
      this.addAnimal = this.formBuilder.group ({
        _id: [],
        animal_id: ['', Validators.required],
        name: ['', Validators.required],
        animal_type: ['', Validators.required],
        breed: ['', Validators.required],
        sex: ['', Validators.required],
        age: ['', Validators.required],
        color: ['', Validators.required],
        admittance: ['', Validators.required],
        animal_status: ['', Validators.required],
        latitude: ['', Validators.required],
        longitude: ['', Validators.required],
      })
    }

    // Check if user has submitted entry and validate submission so it can be inserted into the database
    public onSubmit() {
      this.submitted = true;
      if(this.addAnimal.valid) {
        this.animalService.addAnimal(this.addAnimal.value)
          .subscribe( {
            next: (data: any) => {
              console.log("Inserted data: ", data);
              this.router.navigate(['']);
              alert("Animal Inserted. Please refresh the page for the table to update with the new animal.");
            },
            error: (error: any) => {
              console.log('Error: ' + error);
            }
          })
      }
    }

    // Close add animal component and reroute back to front end if user cancels 
    public onCancel() {
      this.router.navigate(['']);
    }

    // Get the form short name to access form fields
    get f() { return this.addAnimal.controls; }
}
