const express = require("express");

// Add routers into application
var apiRouter = require('./app_api/routes/index');

// Add in database file
require('./app_api/models/db')

// Add in the dotenv JWT Secret
// Note: the .env file is included in this project as it is a proof of concept, but it shoud NEVER be included in
// in an actual product put into production 
require('dotenv').config();

// Add in the authentication module
var passport = require('passport');
require('./app_api/config/passport');

const app = express();

var corsConfig = {
    origin: "http//localhost:3000"
};


app.use(express.json());
app.use(express.urlencoded({ extended: false}));
app.use(passport.initialize());

// Enable cross origin refrencing to allow for angular front end to utilize API and gather/manage data from the database
app.use('/api', (req, res, next) => {
    res.header('Access-Control-Allow-Origin', 'http://localhost:4200');
    res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept, Authorization');
    res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE');
    next();
})

// Catch any unauthorized errors and create 401
app.use((err, req, res, next) => {
    if (err.name === 'UnauthorizedError') {
        res.status(401).json({ "message": err.name + ": " + err.message });
    }
});

app.use('/api', apiRouter);

const PORT = process.env.PORT || 3000;

app.listen(PORT, () => {
    console.log(`Server listening on port ${PORT}.`);
})

module.exports = app;