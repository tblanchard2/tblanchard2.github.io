----------------------------------------------------------------------------------------------------------------------------------
To utilize this program, please make sure you have MongoDB Compass installed to directly access the database and ensure data entries are properly stored

Link to download:
https://www.mongodb.com/products/tools/compass
----------------------------------------------------------------------------------------------------------------------------------
Setting up the program:

To set up the program, you will need to have two powershell windows open (recommended in administrator mode)

Call "cd (directory to file)\CS-499-AnimalShelter" for the backend
Call "cd (directory yo file)\CS-499-AnimalShelter\app_client" for the frontend

In the first (backend) shell, run the following commands

node .\app_api\models\seed
node .\app_api\models\seedUsers

If MongoDB is set up correctly, this will insert the starting data for both the animals and admin credentials into the proper database to be used in this application, with the shell window mentioning Mongoose being connected then disconnected shortly after

If you want to change the amount of animals stored in the animal database, simply go to the seed.js file under app_api\models\seed.js and change the seedAmount value to whatever you want (by default it is 10,000) and running the above node commands again

Once the data is set, simply run in order:
"npm start" on the first window, and wait until mongoose says it's connected 
"ng serve" on the second window

Should everything be in order, the application will build, and the dashboard can be accessed on a browser by going to:

http://localhost:4200/
----------------------------------------------------------------------------------------------------------------------------------
Using the Admin CRUD Functions

To access the CRUD functions, select the login button and enter a valid set of admin credentials

The default credentials to log into the dashboard as an administrator are
name: Admin
email: AdminGS@gmail.com
password: AdminPass

Should that not work, or if you want to create your own credentials, you must make an api call to the server (which can be done using Postman | https://www.postman.com/) with the url:

http://localhost:3000/api/register

and with the key-value pairs of:

name: ( )
email: ( )
password: ( )

in the body section with x-www-form-urlencoded