const mongoose = require('mongoose');
const Animal = require('../models/animals')
const Model = mongoose.model('animals');

// GET: /animals - lists all animals from database | CRUD READ Function
const animalsList = async (req, res) => {
    
    // Query database to gather all entries
    const q = await Model
        .find({}).exec();
    if(q){
        return res.status(200).json(q);
    }
    else{
        return res.status(404).json("Error: Querry unsuccessful");
    }
};

const animalsWaterRescue = async (req, res) => {
    const q = await Model
        .find({
            'animal_type' : 'Dog',
            'breed': {'$in': ['Labrador Retriever',
                    'Chesapeake Bay Retriever',
                    'Newfoundland'
                   ]},
            'sex' : 'Intact Female',
            'age' : {'$in': ['3 Years',
                            '2 Years',
                            '1 Year',
                            '11 Months',
                            '10 Months',
                            '9 Months',
                            '8 Months',
                            '7 Months',
                            '6 Months'
               ]},
            'animal_status': 'Sheltered'
        }).exec();

    if(q){
        return res.status(200).json(q);
    }
    else{
        return res.status(404).json("Error: Querry unsuccessful");
    }
};


const animalWildRescue = async (req, res) => {
    const q = await Model
        .find({
            'animal_type' : 'Dog',
            'breed': {'$in': ['German Shepherd',
                            'Alaskan Malamute',
                            'Old English Sheepdog',
                            'Siberian Husky',
                            'Rottweiler'
               ]},
            'sex' : 'Intact Male',
            'age' : {'$in': ['3 Years',
                            '2 Years',
                            '1 Year',
                            '11 Months',
                            '10 Months',
                            '9 Months',
                            '8 Months',
                            '7 Months',
                            '6 Months'
               ]},
            'animal_status': 'Sheltered'
        }).exec();

    if(q){
        return res.status(200).json(q);
    }
    else{
        return res.status(404).json("Error: Querry unsuccessful");
    }
};

const animalDisasterTracking = async (req, res) => {
    const q = await Model
        .find({
            'animal_type' : 'Dog',
            'breed': {'$in': ['Doberman Pinscher',
                            'German Shepherd',
                            'Golden Retriever',
                            'Bloodhound',
                            'Rottweiler'
               ]},
            'sex' : 'Intact Male',
            'age' : {'$in': ['6 Years',
                            '5 Years',
                            '4 Years',
                            '3 Years',
                            '2 Years',
                            '1 Year',
                            '11 Months',
                            '10 Months',
                            '9 Months',
                            '8 Months',
                            '7 Months',
                            '6 Months',
                            '5 Months',
                            '4 Months'
               ]},
            'animal_status': 'Sheltered'
        }).exec();

    if(q){
        return res.status(200).json(q);
    }
    else{
        return res.status(404).json("Error: Querry unsuccessful");
    }
};

const animalAdoptAvailable = async (req, res) => {
    const q = await Model
        .find({
            'animal_status': 'Sheltered'
        }).exec();

    if(q){
        return res.status(200).json(q);
    }
    else{
        return res.status(404).json("Error: Querry unsuccessful");
    }
};

// GET: /animals/animal_id - lists a singular animal from the database
const animalGetOne = async (req, res) => {

    //Query database ot gather the first entry with the corresponding aninal_id
    const q = await Model
        .findOne({ 'animal_id': req.params.entryid }).exec();
    if (q) {
        return res.status(200).json(q);
    }
    else {
        return res.status(404).json("Error: Querry unsuccessful");
    }
}

// POST: /animals - adds a new animal to database | CRUD CREATE Function
const animalCreate = async (req, res) => {
    const newAnimal = new Animal({
        animal_id: req.body.animal_id,
        name: req.body.name,
        animal_type: req.body.animal_type,
        breed: req.body.breed,
        sex: req.body.sex,
        age: req.body.age,
        color: req.body.color,
        admittance: req.body.admittance,
        animal_status: req.body.animal_status,
        latitude: req.body.latitude,
        longitude: req.body.longitude
    });
    try{
        
        // Query database to add new animal
        const q = await newAnimal.save();
        if(q){
            return res.status(201).json(q);
        }
        else{
            return res.status(400).json("Error: Query unsuccessful");
        }
    }catch(error){
        if(error.name == 'ValidationError'){
            return res.status(400).json("Error: The query is invalid. Please make sure to include all required parts");
        }
        else{
            return res.status(400).json("An unexpected error has occured");
        }
    }
};

// PUT: /animals/animal_id - updates a specified animal based on id | CRUD UPDATE Function
const animalUpdate = async (req, res) => {
    
    // Query database to update existing animal
    const q = await Model
        .findOneAndUpdate(
            {'animal_id' : req.params.entryid},
            {
                animal_id : req.body.animal_id,
                name : req.body.name,
                animal_type : req.body.animal_type,
                breed : req.body.breed,
                sex : req.body.sex,
                age : req.body.age,
                color : req.body.color,
                admittance : req.body.admittance,
                animal_status : req.body.animal_status,
                latitude: req.body.latitude,
                longitude: req.body.longitude
            }
        ).exec();

    try{
        if(q){
            return res.status(201).json(q);
        }
        else{
            return res.status(400).json('Error: Querry unsuccessful');
        }
    }
    catch(error){
        if(error.name == 'ValidationError'){
            return res.status(400).json("Error: The query is invalid. Please make sure to include all required parts");
        }
        else{
            return res.status(400).json("An unexpected error has occured");
        }
    }
};


// DELETE /animals/animal_id - deletes a specififed animal based on id | CRUD DELETE Function
const animalDelete = async (req, res) => {

    // Query database to delete existing animal
    const q = await Model
        .deleteOne(
            {'animal_id' : req.params.entryid}
        ).exec();
    if(q){
        return res.status(200).json(q);
     }
      else{
          return res.status(404).json("Error: Querry unsuccessful");
       }
};

module.exports = {
    animalsList,
    animalGetOne,
    animalCreate,
    animalUpdate,
    animalDelete,
    animalsWaterRescue,
    animalWildRescue,
    animalDisasterTracking,
    animalAdoptAvailable
};