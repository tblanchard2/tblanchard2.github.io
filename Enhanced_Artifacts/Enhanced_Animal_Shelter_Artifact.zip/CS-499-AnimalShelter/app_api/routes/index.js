const express = require('express');
const router = express.Router();
const animalController = require('../controllers/animalsCRUD');
const authController = require('../controllers/authentication');
const jwt = require('jsonwebtoken');

// Authenticate given JWT token to ensure user instance is authenticated to access administrative portions of the application
function authenticateJWT(req, res, next) {
    
    const authHeader = req.headers['authorization'];

    if(authHeader == null){
        console.log('Auth Header required but NOT present');
        return res.sendStatus(401);
    }

    let headers = authHeader.split(' ');
    if(headers.length < 1){
        console.log('Not enough tokens in Auth Header' + headers.length);
        return res.sendStatus(501);
    }

    const token = authHeader.split(' ')[1];
    console.log('Token is: ' + token);

    if(token == null){
        console.log('Token is Null');
        return res.sendStatus(401);
    }

    const verified = jwt.verify(token, process.env.JWT_SECRET, (err, verified) => {
        if(err){
            return res.sendStatus(401).json('Token Validation Error');
        }
        req.auth = verified;
    });
    next();
}

// Routers used to route each request to its respective function

router.post('/register', authController.register);

router.post('/login', authController.login);

router.get('/animals', animalController.animalsList);

router.get('/animals-water', animalController.animalsWaterRescue);

router.get('/animals-wild', animalController.animalWildRescue);

router.get('/animals-tracking', animalController.animalDisasterTracking);

router.get('/animals-adoptable', animalController.animalAdoptAvailable);

router.get('/animals/:entryid', animalController.animalGetOne);

// Administrative routers that require authentication to ensure only admins can access these methods

router.post('/animals', authenticateJWT, animalController.animalCreate);

router.put('/animals/:entryid', authenticateJWT, animalController.animalUpdate);

router.delete('/animals/:entryid', authenticateJWT, animalController.animalDelete);

module.exports = router;