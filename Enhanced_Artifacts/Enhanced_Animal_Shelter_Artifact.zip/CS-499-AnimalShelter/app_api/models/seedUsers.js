const mongoose = require('./db');
const users = require('./users');

/************************************************************************************* 
 * Seeding component used to seed the user (admin) database with default admin
 * credentials
*************************************************************************************/ 

// Read static seeding data from users.json file
var fs = require('fs');
var user_data = JSON.parse(fs.readFileSync('./data/users.json', 'utf8'));


// Delete any existing entries and insert data for fresh database
const seedDB = async () => {
    await users.deleteMany({});
    await users.insertMany(user_data);
}

// Close database connection and exit
seedDB().then(async () => {
    await mongoose.connection.close();
    process.exit(0);
})