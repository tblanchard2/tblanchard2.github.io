const mongoose = require('./db');
const animals = require('./animals');

/************************************************************************************* 
 * Seeding component used to dynamically seed the animals database with a select amount
 * animals, determined by the seedAmount variable
 * 
 * Due to all of the random data options (besides the coordinates) being strings,
 * some data entries may not be 100% sensical, but still serves its purpose as a 
 * proof of concept
*************************************************************************************/ 

// Read static seeding data from animals.json file
// Depricated but left in case if random seeding below doesn't work
// Simply swap variable in insertMany(XXXX) with animal_data to use static data
//var fs = require('fs');
//var animal_data = JSON.parse(fs.readFileSync('./data/animals.json', 'utf8'));

var animal_names = ['Luna', 'Bella', 'Bear', 'Duke', 'Buddy', 'Callie', 'Charlie', 'Max', 'Milo', 'Daisy', 'Oliver', 'Clemintine', 'Lucy', 'Leo', 'Coco', 'Buddy', 'Bud', 'Thorne', 
                    'Jasper', 'Teddy', 'Rocky', 'Loki', 'Blueberry', 'Nala', 'Bart', 'Cookie', 'Bartholemu', 'Abbie', 'Abby', 'Amber', 'Angel', 'Daisy', 'Delilah', 'Diva', 'Dixie',
                    'Emma', 'Eva', 'Elsa', 'Bella', 'Bonnie', 'Biscuit', 'Betty', 'Foxy', 'Frank', 'Gabby', 'Holly', 'Honey', 'Jade', 'Jenny', 'Jaz', 
                    'Lilly', 'Lucky', 'Lola', 'Lulu', 'Maddy', 'Maisy', 'Marley', 'Raven', 'Muffin', 'Paris', 'Oreo', 'Olivia', 'Nola', 'Reese', 'Riley',
                    'Sage', 'Sammy', 'Sandy', 'Sassy', 'Sasha', 'Sam', 'Sheba', 'Scarlet', 'Stella', 'Summer', 'Spike', 'Polly', 'Tess', 'Tinkerbell', 'Tootsie',
                    'Violet', 'Trixie', 'Willow', 'Winnie', 'Xena', 'Ziva', 'Zoe', 'Zoey', 'Candy', 'Charlotte', 'Carly', 'Callie', 'Cricket', 'Cleo', 'Ivy',
                    'Izzy', 'Jackie', 'Jake', 'Kaya', 'Khloe', 'Piper', 'Pumpkin', 'Precious', 'Pixie', 'Pippa', 'Sparky', 'Mickey', 'Snickers', 'Mabel', 'Macy'];
var animal_types = ["Dog", "Dog", "Dog", "Cat"];
var animal_breeds = ['German Shepherd', 'Alaskan Malamute', 'Old English Sheepdog', 'Siberian Husky', 'Rottweiler', 'Labrador Retriever', 'Chesapeake Bay Retriever', 'Newfoundland', 
                    'Doberman Pinscher', 'Bloodhound', 'French Bulldog', 'Pug', 'Jack Russel', 'Golden Retriever', 'Dachshund', 'Beagle', 'Welsh Corgi', 'Yorkshire Terrier',
                    'Cane Corso', 'Great Dane', 'Shih Tzu', 'Border Collie', 'Chihuahua', 'Dalmatian', 'Boston Terrier', 'St. Bernard', 'Boxer', 'Pitbull', 'Shiba Inu', 'Borzoi', 'Shetland Sheepdog', 'Harrier', 'Briard'];
var animal_gender = ['Male', 'Female', 'Intact Male', 'Intact Female'];
var animal_age = ['< 1 Month', '1 Month', '2 Months', '3 Months', '4 Months', '5 Months', '6 Months', '7 Months', '8 Months', '9 Months', '10 Months', '11 Months',
                    '1 Year', '2 Years', '3 Years', '4 Years', '5 Years', '6 Years', '7 Years', '8 Years', '9 Years', '10 Years', '11 Years', '12 Years'];
var animal_color = ['White', 'Yellow', 'Tan', 'Blond','Black','Brown','White w/ Brown Spots','White w/ Black Spots','Silver', 'Brown w/ White Spots', 'Brown w/ Black Spots',
                    'Black w/ White Spots', 'Black w/ Tan Spots', 'White w/ Tan Spots', 'White w/ silver spots'];
var animal_status = ['Sheltered', 'Sheltered', 'Sheltered', 'Sheltered', 'Sheltered', 'Undergoing Adoption', 'Adopted', 'Aggressive']
var shelter_latitides = [30.342747, 30.303287, 30.302793, 30.295967];
var shelter_longitudes = [-97.701719, -97.701605, -97.746745, -97.767941];

// The amount of entries to seed into the database
var seedAmount = 10000;



// Delete any existing entries and insert data for fresh database
const seedDB = async () => {
    await animals.deleteMany({});
    
    for(i = 1; i < seedAmount + 1; i++){
        let id = i;
        let name = animal_names[Math.floor(Math.random() * animal_names.length)];
        let type = animal_types[Math.floor(Math.random() * animal_types.length)];
        let breed = '';
        if(type == "Dog"){
            breed = animal_breeds[Math.floor(Math.random() * animal_breeds.length)];
        }else breed = "Cat";
        let sex = animal_gender[Math.floor(Math.random() * animal_gender.length)];
        let age = animal_age[Math.floor(Math.random() * animal_age.length)];
        let color = animal_color[Math.floor(Math.random() * animal_color.length)];
        let status = animal_status[Math.floor(Math.random() * animal_status.length)];
        let year = Math.floor(Math.random() * 5) + 2020;
        let month = Math.floor(Math.random() * 12) + 1;
        let monthStr = '';
        if(month - 10 < 0){
            monthStr = '0' + month;
        }
        let day = Math.floor(Math.random() * 28) + 1;
        let dayStr = '';
        if(day - 10 < 0){
            dayStr = "0" + day;
        }
 
        let admittance = year + "-" + monthStr + "-" + dayStr;
        let coords = Math.floor(Math.random() * shelter_latitides.length);
        let lat = shelter_latitides[coords];
        let lon = shelter_longitudes[coords];

        let newAnimal = {
            animal_id: id,
            name: name,
            animal_type: type,
            breed: breed,
            sex: sex,
            age: age,
            color: color,
            admittance: admittance,
            animal_status: status,
            latitude: lat,
            longitude: lon
        };

        //console.log(newAnimal);
        await animals.insertMany(newAnimal);
        
    }


}

// Close database connection and exit
seedDB().then(async () => {
    await mongoose.connection.close();
    process.exit(0);
})