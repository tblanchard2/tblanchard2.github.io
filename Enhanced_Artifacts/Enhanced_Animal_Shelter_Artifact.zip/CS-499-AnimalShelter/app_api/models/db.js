const mongoose = require("mongoose");
const host = process.env.DB_HOST || '127.0.0.1';
const dbURI = `mongodb://${host}/animals`
const readLine = require ('readline');

// Build connection to database and timeout if connection takes too long (likely cannot find database)
const connect = () => {
    setTimeout(() => mongoose.connect(dbURI, {
    }), 1000); //Time in miliseconds until connection times out
}

//Mongoose connections events to state when mongoose connects or disconnects from the database
mongoose.connection.on('connected', () => {
    console.log("Mongoose connected");
})

mongoose.connection.on('error', err => {
    console.log("Error connecting to database: ", err);
})

mongoose.connection.on('disconnected', () => {
    console.log("Mongoose disconnected");
})

connect();

require('./animals');
module.exports = mongoose;