const mongoose = require("mongoose");

// Define the schema for the animals within the database
const animalSchema = new mongoose.Schema({
    animal_id: {type: String, required: true, index: true},
    name: {type: String, required: true, index: true},
    animal_type: {type: String, required: true, index: true},
    breed: {type: String, required: true, index: true},
    sex: {type: String, required: true},
    age: {type: String, required: true},
    color: {type: String, required: true},
    admittance: {type: String, required: true, index: true},
    animal_status: {type: String, required: true},
    latitude: {type: Number, required: true},
    longitude: {type: Number, required: true},
});
const Animals = mongoose.model('animals', animalSchema);
module.exports = Animals;