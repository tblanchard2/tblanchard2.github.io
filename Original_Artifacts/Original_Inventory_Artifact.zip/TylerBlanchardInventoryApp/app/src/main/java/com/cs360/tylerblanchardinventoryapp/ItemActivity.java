package com.cs360.tylerblanchardinventoryapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Context;
import android.content.DialogInterface;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.telephony.TelephonyManager;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.cs360.tylerblanchardinventoryapp.model.Item;
import com.cs360.tylerblanchardinventoryapp.repo.ItemRepository;

import java.util.Objects;

public class ItemActivity extends AppCompatActivity {

    private SmsManager notifManager;
    private ItemRepository itemRepo;
    private Item dItem;
    private long itemId;
    private TextView itemTitle;
    private TextView itemQuantity;
    private EditText amountChange;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_item);
        itemRepo = ItemRepository.getInstance(getApplication().getApplicationContext());

        if(getIntent().hasExtra("ITEM")){
            dItem = getIntent().getSerializableExtra("ITEM", Item.class);
        }

        itemTitle = findViewById(R.id.itemNameView);
        itemQuantity = findViewById(R.id.itemDescQuantityView);
        amountChange = findViewById(R.id.editQuantityEditText);

        Objects.requireNonNull(getSupportActionBar()).setTitle(getString(R.string.itemMenuTitle, dItem.getTitle()));

        if(dItem != null){
            itemId = dItem.getId();
            itemTitle.setText(dItem.getTitle());
            updateQuantityDisplay();
        }


    }

    //Sets the referenced item to the database's item to retain accurate referencing
    private void refreshItem(){
        dItem = itemRepo.getItemById(itemId);
        updateQuantityDisplay();
    }

    //Updates the quantity display to show the accurate quantity when a change occurs
    private void updateQuantityDisplay(){
        String quantity = getString(R.string.itemQuantity, String.valueOf(dItem.getQuantity()));
        itemQuantity.setText(quantity);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu){
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.item_menu, menu);

        return true;
    }

    public boolean onOptionsItemSelected(@NonNull MenuItem item){

        if(item.getItemId() == R.id.sendNotificationMenu){
            checkSMSPermission();
            return true;
        }
        else if(item.getItemId() == R.id.itemRemoveMenu){
            confirmRemoveDialog();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    //Decreases the item's quantity by the entered amount when the decrease button is pressed
    //Quantity cannot go below 0 (you can't have a negative amount of a physical item)
    public void onButtonDecrease(View view){
        int oldQuantity = dItem.getQuantity();
        int changeAmount;
        try {   //Ensure that entered quantity is a number, else set quantity changing to zero
            changeAmount = Integer.parseInt(amountChange.getText().toString());
        } catch (NumberFormatException e) {
            changeAmount = 0;
        }
        //Check if quantity is 0 or less before updating the database
        int newQuantity = checkNoStock(oldQuantity - changeAmount, oldQuantity);
        itemRepo.updateItemQuantity(newQuantity, itemId);
        refreshItem();
    }

    //Increases the item's quantity by the entered amount when the increase button is pressed
    //Checks for quantity being zero or less as user is able to enter a negative number if they desire
    public void onButtonIncrease(View view){
        int oldQuantity = dItem.getQuantity();
        int changeAmount;
        try {   //Ensure that entered quantity is a number, else set quantity changing to zero
            changeAmount = Integer.parseInt(amountChange.getText().toString());
        } catch (NumberFormatException e) {
            changeAmount = 0;
        }
        //Check if quantity is 0 or less before updating the database
        int newQuantity = checkNoStock(oldQuantity + changeAmount, oldQuantity);
        itemRepo.updateItemQuantity(newQuantity, itemId);
        refreshItem();

    }

    //Checks if an item's quantity is out of stock (0 or less) and notifies user via SMS if so
    //Second argument checks if the quantity before any change was already zero to prevent multiple out of stock notifications
    //if the stock was already 0
    private int checkNoStock(int quantity, int original){
        if(quantity <= 0){
            //Checks if user has enabled the proper permissions and if original quantity is not already zero
            if(ContextCompat.checkSelfPermission(ItemActivity.this, android.Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED
            && ContextCompat.checkSelfPermission(ItemActivity.this, Manifest.permission.READ_PHONE_NUMBERS) == PackageManager.PERMISSION_GRANTED
            && original > 0){
                //Gathers the device's phone number and sends a notification about an item going out of stock
                String message = getString(R.string.itemOutOfStockNotification, dItem.getTitle());
                TelephonyManager manager = (TelephonyManager) this.getSystemService(Context.TELEPHONY_SERVICE);
                notifManager = SmsManager.getDefault();
                notifManager.sendTextMessage(manager.getLine1Number(),null,message,null,null);
            }
            return 0;
        }
        else{
            return quantity;
        }

    }

    //Displays a dialog asking user to confirm their decision to delete an item
    public void confirmRemoveDialog(){
        AlertDialog.Builder alert = new AlertDialog.Builder(this);
            alert.setTitle(R.string.removeItemTitle);
            alert.setMessage(R.string.removeItemMessage);
            alert.setPositiveButton(R.string.removeYes, new DialogInterface.OnClickListener(){
                public void onClick(DialogInterface dialog, int id){
                    //Removes the item from the database and finishes this activity, as this item will no longer exist
                    Toast.makeText(ItemActivity.this, R.string.itemRemoved, Toast.LENGTH_SHORT).show();
                    itemRepo.deleteItem(dItem);
                    finish();
                }
            });
            alert.setNegativeButton(R.string.removeNo, new DialogInterface.OnClickListener(){
                public void onClick(DialogInterface dialog, int id){
                    //Do nothing and close dialog
                }
            });
            alert.create().show();
    }

    //Checks for permission to receive user's phone number and send SMS notifications
    //Asks user to enable permissions if denied, or notifies user that notifications are already enabled
    //Users can enable the activity to request permissions by pressing on the message/SMS icon to the
    //left of the overflow menu on the activity's action bar
    public void checkSMSPermission(){
        if(ContextCompat.checkSelfPermission(ItemActivity.this, android.Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_DENIED
          || ContextCompat.checkSelfPermission(ItemActivity.this, Manifest.permission.READ_PHONE_NUMBERS) == PackageManager.PERMISSION_DENIED){
            ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.SEND_SMS, Manifest.permission.READ_PHONE_NUMBERS, Manifest.permission.READ_PHONE_STATE}, 1234);
        }
        else{
            Toast.makeText(ItemActivity.this, R.string.notificationsEnabled, Toast.LENGTH_SHORT).show();
        }
    }

}