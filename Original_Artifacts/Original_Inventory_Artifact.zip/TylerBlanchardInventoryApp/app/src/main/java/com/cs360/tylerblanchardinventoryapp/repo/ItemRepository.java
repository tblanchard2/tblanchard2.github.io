package com.cs360.tylerblanchardinventoryapp.repo;

import android.content.Context;

import androidx.room.Room;

import com.cs360.tylerblanchardinventoryapp.model.Item;

import java.util.List;

//Singleton Item Repository to allow classes to interact with the item database
//Classes can utilize full CRUD functionality using this repository
public class ItemRepository {

    private static ItemRepository mItemRepo;
    private final ItemDao mItemDao;

    public static ItemRepository getInstance(Context context){
        if(mItemRepo == null){
            mItemRepo = new ItemRepository(context);
        }
        return mItemRepo;
    }

    private ItemRepository(Context context){
        ItemDatabase idb = Room.databaseBuilder(context, ItemDatabase.class, "item.db")
                .allowMainThreadQueries()
                .build();
        mItemDao = idb.itemDao();

        if(mItemDao.getAll().isEmpty()){
            addStarterDataDebug();
        }

    }

    //Creates starting sample data if the database is initially blank
    private void addStarterDataDebug(){
        Item ex1 = new Item("Matches", 53);
        mItemDao.addItem(ex1);
        Item ex2 = new Item("Toys", 24);
        mItemDao.addItem(ex2);
        Item ex3 = new Item("Plastic Chairs", 5);
        mItemDao.addItem(ex3);
        Item ex4 = new Item("Pencils", 634);
        mItemDao.addItem(ex4);
    }

    public List<Item> getAllItems(){
        return mItemDao.getAll();
    }
    public void addItem(Item item){
        mItemDao.addItem(item);
    }
    public void updateItemQuantity(int quantity, long id) {mItemDao.updateItemQuantity(quantity,id);}
    public void deleteItem(Item item) {mItemDao.deleteItem(item);}
    public Item getItemById(long id) {return mItemDao.getItemById(id);}
    public List<Item> getSearchItems(String search) {return mItemDao.getAllSearch(search);}

}
