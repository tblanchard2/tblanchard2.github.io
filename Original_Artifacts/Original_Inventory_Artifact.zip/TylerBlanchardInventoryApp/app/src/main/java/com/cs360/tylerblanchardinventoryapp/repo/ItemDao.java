package com.cs360.tylerblanchardinventoryapp.repo;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;

import com.cs360.tylerblanchardinventoryapp.model.Item;

import java.util.List;

@Dao
public interface ItemDao {
    @Query("SELECT * FROM item")
    List<Item> getAll();

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    long addItem(Item item);

    @Delete
    void deleteItem(Item item);

    @Query("UPDATE item SET quantity=:newQuantity WHERE id = :id")
    void updateItemQuantity(int newQuantity, long id);

    @Query("SELECT * FROM item WHERE id = :id LIMIT 1")
    Item getItemById(long id);

    @Query("SELECT * FROM item WHERE title LIKE :input")
    List<Item> getAllSearch(String input);
}
