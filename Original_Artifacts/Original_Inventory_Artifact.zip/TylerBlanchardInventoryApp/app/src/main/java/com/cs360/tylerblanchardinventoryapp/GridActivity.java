package com.cs360.tylerblanchardinventoryapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.cs360.tylerblanchardinventoryapp.model.Item;
import com.cs360.tylerblanchardinventoryapp.repo.ItemRepository;

import java.util.List;
import java.util.Objects;

public class GridActivity extends AppCompatActivity {

    private ItemRepository itemRepo;
    public FragmentManager fragmentManager;
    public AddItemFragment addFragment;
    public EditText addName;
    public EditText addQuantity;
    private EditText searchBar;
    private String searchValue = "";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_grid);

        Objects.requireNonNull(getSupportActionBar()).setTitle(R.string.gridMenuTitle);

        itemRepo = ItemRepository.getInstance(getApplication().getApplicationContext());


        addFragment = new AddItemFragment();
        fragmentManager = getSupportFragmentManager();
        searchBar = findViewById(R.id.searchEditText);
        //Editor listener to check for when user enters something on the search bar
        searchBar.setOnEditorActionListener(new TextView.OnEditorActionListener(){

            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                //Check is user has pressed the done button on the phone keyboard
                if(actionId == EditorInfo.IME_ACTION_DONE || event != null && event.getAction() == KeyEvent.ACTION_DOWN &&
                        event.getKeyCode() == KeyEvent.KEYCODE_ENTER){
                    if(event == null || !event.isShiftPressed()){
                        //Hide keyboard when user is finished typing
                        InputMethodManager inManager = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                        inManager.hideSoftInputFromWindow(GridActivity.this.getCurrentFocus().getWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS);
                        //Assign the search value to the string the user inputs
                        searchValue = searchBar.getText().toString();
                        onResume();
                        return true;
                    }
                }
                return false;
            }
        });


    }

    //Implements recyclable list whenever the app is resumed to allow for correct updating of data when an entry
    //is removed in the item activity
    @Override
    protected void onResume() {
        super.onResume();

        List<Item> repoData;

        //Gathers appropriate data depending on if the user has entered anything on the search bar
        //By default all items are gathered
        if(searchValue.isEmpty()) {
            repoData = itemRepo.getAllItems();
        }
        else{
            repoData = itemRepo.getSearchItems(searchValue);
        }

        //Creates recyclable list items
        //Utilizes the GridLayoutManager to put multiple entries on a singular row
        RecyclerView itemView = findViewById(R.id.inventory_list);
        RecyclerView.LayoutManager gridLayoutManager = new GridLayoutManager(getApplicationContext(), 2);
        GridAdapter adapter = new GridAdapter(repoData);
        GridLayoutManager layoutManager = new GridLayoutManager(this,2);
        itemView.setLayoutManager(layoutManager);
        itemView.setAdapter(adapter);


        //Opens item activity based on the item/card clicked
        adapter.setOnClickListener(new GridAdapter.OnCardClickListener(){
            @Override
            public void onCardClick(int position, Item item) {
                Log.d("click", String.valueOf(item.getId()));
                Intent intent = new Intent(GridActivity.this, ItemActivity.class);
                intent.putExtra("ITEM", item);
                startActivity(intent);
            }

        });

    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu){
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.grid_menu, menu);

        return true;
    }

    public boolean onOptionsItemSelected(@NonNull MenuItem item){

        if(item.getItemId() == R.id.gridLogoutMenu){
            confirmLogout();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    //Opens the add item fragment when the floating action button is pressed
    public void onFabAddClicked(View view){
        //Ensure that fragment isn't already visible when pressing button
        Fragment existingFragment = fragmentManager.findFragmentById(R.id.addFragmentContainerView);
        if(existingFragment == null) {
            fragmentManager.beginTransaction().setReorderingAllowed(true)
                    .add(R.id.addFragmentContainerView, addFragment, null)
                    .commit();
        }
    }

    //Creates new item and adds it to the item database when create is clicked
    //Reloads the activity to display the new item
    public void onCreateClicked(View view){

        //Finds and assigns the EditText boxes from fragment
        View fragmentView = Objects.requireNonNull(fragmentManager.findFragmentById(R.id.addFragmentContainerView)).getView();
        addName = (EditText) fragmentView.findViewById(R.id.addItemNameText);
        addQuantity = (EditText) fragmentView.findViewById(R.id.addItemQuantityText);

        String name = addName.getText().toString();
        //Name must be something to be put into the database
        if(!name.isEmpty()) {
            int quantity;
            try {   //Ensure that entered quantity is a number, else set starting quantity to zero
                quantity = Integer.parseInt(addQuantity.getText().toString());
            } catch (NumberFormatException e) {
                quantity = 0;
            }
            Log.d("Added Item", "New item: " + name + " quantity: " + quantity);

            addName.getText().clear();
            addQuantity.getText().clear();

            Item newItem = new Item(name, quantity);
            itemRepo.addItem(newItem);

            //Closes fragment once item is created
            fragmentManager.beginTransaction()
                    .remove(fragmentManager.findFragmentById(R.id.addFragmentContainerView))
                    .commit();

            //Reload recycler view to display new data
            onResume();
        }
        else{
            Toast.makeText(GridActivity.this, R.string.noAddName, Toast.LENGTH_SHORT).show();
        }
    }

    //Clears any text in fragment editText boxes and closes fragment
    public void onCancelClicked(View view){

        //Finds and assigns the EditText boxes from fragment
        View fragmentView = Objects.requireNonNull(fragmentManager.findFragmentById(R.id.addFragmentContainerView)).getView();
        addName = (EditText) fragmentView.findViewById(R.id.addItemNameText);
        addQuantity = (EditText) fragmentView.findViewById(R.id.addItemQuantityText);

        addName.getText().clear();
        addQuantity.getText().clear();

        fragmentManager.beginTransaction()
                .remove(fragmentManager.findFragmentById(R.id.addFragmentContainerView))
                .commit();
    }

    //Dialog menu to finish activity and move back to login activity when user wants to log out
    public void confirmLogout(){
        AlertDialog.Builder alert = new AlertDialog.Builder(this);
        alert.setTitle(R.string.logoutTitle);
        alert.setMessage(R.string.logoutMessage);
        alert.setPositiveButton(R.string.logoutYes, new DialogInterface.OnClickListener(){
            public void onClick(DialogInterface dialog, int id){
                Toast.makeText(GridActivity.this, R.string.logOutNotif, Toast.LENGTH_SHORT).show();
                finish();
            }
        });
        alert.setNegativeButton(R.string.logoutNo, new DialogInterface.OnClickListener(){
            public void onClick(DialogInterface dialog, int id){
                //Do nothing but close dialog
            }
        });
        alert.create().show();
    }



}