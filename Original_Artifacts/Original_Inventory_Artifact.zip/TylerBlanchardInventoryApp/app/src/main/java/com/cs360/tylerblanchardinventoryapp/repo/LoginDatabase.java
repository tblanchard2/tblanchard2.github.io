package com.cs360.tylerblanchardinventoryapp.repo;

import androidx.room.Database;
import androidx.room.RoomDatabase;

import com.cs360.tylerblanchardinventoryapp.model.Login;

@Database(entities = {Login.class}, version = 1)
public abstract class LoginDatabase extends RoomDatabase {
    public abstract LoginDao loginDao();
}
