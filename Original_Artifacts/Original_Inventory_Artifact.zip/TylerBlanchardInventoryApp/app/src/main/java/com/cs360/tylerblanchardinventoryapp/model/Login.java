package com.cs360.tylerblanchardinventoryapp.model;

import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity
public class Login {

    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "id")
    public long mID;
    @ColumnInfo(name = "username")
    public String mUsername;
    @ColumnInfo(name = "password")
    public String mPassword;

    public Login(@NonNull String username, String password){
        mUsername = username;
        mPassword = password;
    }

    public String getPassword(){
        return mPassword;
    }

    public String getUsername(){
        return mUsername;
    }

}
