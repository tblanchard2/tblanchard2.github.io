package com.cs360.tylerblanchardinventoryapp.model;

import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

import java.io.Serializable;

@Entity
public class Item implements Serializable {

    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "id")
    public long mID;
    @ColumnInfo(name = "title")
    public String mTitle;
    @ColumnInfo(name = "quantity")
    public int mQuantity;

    public Item(@NonNull String title, int quantity){
        mTitle = title;
        mQuantity = quantity;
    }

    public String getTitle() {return mTitle;}

    public int getQuantity() {return mQuantity;}

    public long getId(){return mID;}

    public void setQuantity(int newQuantity) {mQuantity = newQuantity;}


}
