package com.cs360.tylerblanchardinventoryapp;

import androidx.appcompat.app.AppCompatActivity;



import android.content.Intent;

import android.os.Bundle;

import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.cs360.tylerblanchardinventoryapp.model.Login;
import com.cs360.tylerblanchardinventoryapp.repo.LoginRepository;

import java.util.List;

public class LoginActivity extends AppCompatActivity {

    private LoginRepository loginRepo;

    private EditText userText;
    private EditText passText;
    private TextView errorText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        //Login repository used to allow class to interact with login database
        loginRepo = LoginRepository.getInstance(getApplication().getApplicationContext());

        userText = findViewById(R.id.nameText);
        passText = findViewById(R.id.passText);
        errorText = findViewById(R.id.invalidContentView);

    }

    @Override
    public void onStop() {
        super.onStop();

        //Clear username and password text boxes when this activity is stopped (moving to grid activity)
        userText.setText("");
        passText.setText("");
    }

    //Determines if user entered credentials are listed within the database
    //If valid, starts the Grid Activity
    public void OnLoginClicked(View view){

        if(verifyInputs()) {
            String username = userText.getText().toString();
            String password = passText.getText().toString();

            List<Login> validCredentials = loginRepo.getVerificatedCredentials(username, password);

            if (validCredentials.isEmpty()) { //No login credentials with given inputs exist
                errorText.setVisibility(View.VISIBLE);
                errorText.setText(R.string.invalidLogin);
            } else { //Valid login credentials exist
                //DEBUG Log.d("Login", "Valid login of USER: " + username + " PASS: " + password);

                Intent grid = new Intent(getApplicationContext(),GridActivity.class);
                startActivity(grid);

            }
        }

    }

    //Checks is inputted username already exists within the database
    //If username doesn't exist, creates a new account with given unique username and password
    public void OnSignupClicked(View view){

        if(verifyInputs()) {
            String username = userText.getText().toString();
            String password = passText.getText().toString();

            List<Login> matchingUsernames = loginRepo.getMatchingUsernames(username);

            if(matchingUsernames.isEmpty()){ //User inputted unique username

                Login newAccount = new Login(username, password);
                loginRepo.addUser(newAccount);

                Toast.makeText(LoginActivity.this, R.string.successfulSignup, Toast.LENGTH_SHORT).show();
            }
            else{ //Username already exists
                errorText.setVisibility(View.VISIBLE);
                errorText.setText(R.string.invalidSignup);
            }
        }
    }

    //Verify user inputs to ensure username and password are not blank when logging in or signing up
    private boolean verifyInputs(){
        String vUser = userText.getText().toString();
        String vPass = passText.getText().toString();
        if(vUser.isEmpty()){
            errorText.setVisibility(View.VISIBLE);
            errorText.setText(R.string.noUsername);
            return false;
        }
        else if (vPass.isEmpty()){
            errorText.setVisibility(View.VISIBLE);
            errorText.setText(R.string.noPass);
            return false;
        }
        else{
            errorText.setVisibility(View.INVISIBLE);
            return true;
        }
    }



}