from pymongo import MongoClient
from bson.objectid import ObjectId

class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """

    def __init__(self, username, password):
        # Initializing the MongoClient. This helps to 
        # access the MongoDB databases and collections.
        # This is hard-wired to use the aac database, the 
        # animals collection, and the aac user.
        # Definitions of the connection string variables are
        # unique to the individual Apporto environment.
        #
        #
        # Connection Variables
        #
        USER = username
        PASS = password
        HOST = 'nv-desktop-services.apporto.com'
        PORT = 31112
        DB = 'AAC'
        COL = 'animals'
        #
        # Initialize Connection
        #
        self.client = MongoClient('mongodb://%s:%s@%s:%d' % (USER,PASS,HOST,PORT))
        self.database = self.client['%s' % (DB)]
        self.collection = self.database['%s' % (COL)]

# CRUD Create method to add entries into a database.
    def create(self, data):
        if data is not None and isinstance(data,dict):  # Ensures that data is dictonary
            result_insert = self.database.animals.insert_one(data) 
            if result_insert.acknowledged == True: # Returns true if entry is successfully inputted into database
                return True
            else:
                return False
        else:
            raise Exception("Nothing to save, because data parameter is empty or not a dictonary")

# CRUD Read method to find and list items from a database.
    def read(self, data):
        if data is not None and isinstance(data,dict):  # Ensures that data is dictonary
            result_find = list(self.database.animals.find(data)) # Returns the list of found entries based on inputted data
            return result_find
        else:
            raise Exception("Nothing to read, because data parameter is empty or not a dictonary")
            
# Specialized CRUD Update method to find and update the first found item in a dataase            
    def updateOne(self, key, update_data):
        if key is not None and isinstance(key,dict):  # Ensures that data and key are dictonaries
            if update_data is not None and isinstance(update_data,dict):
                result_modified = self.database.animals.update_one(key, {"$set": update_data}) # Updates singular entry with new data
                return result_modified.modified_count  # Returns amount of entries that were modified (which should be just 1)
            else:
                raise Exception("Nothing to update, because update parameter is not a dictonary")
        else:
            raise Exception("Nothing to read, because key parameter is not a dictonary")

# CRUD Update method to find and update all entries with a specific key/value pair
    def update(self, key, update_data):
        if key is not None and isinstance(key,dict):  # Ensures that data and key are dictonaries
            if update_data is not None and isinstance(update_data,dict):
                result_modified = self.database.animals.update_many(key, {"$set": update_data}) # Updates all found entries with new data
                return result_modified.modified_count # Returns the number of entries that were updated/modified
            else:
                raise Exception("Nothing to update, because update parameter is not a dictonary")
        else:
            raise Exception("Nothing to read, because key parameter is not a dictonary")

# CRUD Delete method to remove all entries with a specif key/value pair
    def delete(self, data):
        if data is not None and isinstance(data,dict):  # Ensures that data is dictonary
            result_removed = self.database.animals.delete_many(data)
            return result_removed.deleted_count  # Returns the number of entries that were removed from a database
        else:
            raise Exception("Nothing to remove, because data parameter is not a dictonary")
        